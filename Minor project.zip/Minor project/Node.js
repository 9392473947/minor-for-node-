var http=require("http");
var fs=require("fs");

http.createServer((req,res)=>{
    fs.readFile("minorproject.html",(err,data)=>{
        res.write(data);

        res.end();
        console.log("minor project running successfully in the server port 8080")
    })
}).listen(8080)